import {
    IAppAccessors,
    IHttp,
    ILogger,
    IMessageBuilder,
    IPersistence,
    IRead,
} from '@rocket.chat/apps-engine/definition/accessors';
import {App} from '@rocket.chat/apps-engine/definition/App';
import {IMessage, IPreMessageSentModify} from '@rocket.chat/apps-engine/definition/messages';
import {IAppInfo} from '@rocket.chat/apps-engine/definition/metadata';

export class JiraShortenerApp extends App implements IPreMessageSentModify {

    private findRegex = /h?t?t?p?s?:?\/?\/?jira.bssys.com\/browse\/\w+-\d+/g;

    constructor(info: IAppInfo, logger: ILogger, accessors: IAppAccessors) {
        super(info, logger, accessors);
    }

    public async checkPreMessageSentModify(message: IMessage, read: IRead, http: IHttp): Promise<boolean> {
        if (typeof message.text !== 'string') {
            return false;
        }

        const result = message.text.match(this.findRegex);

        return result ? result.length !== 0 : false;
    }

    public async executePreMessageSentModify(message: IMessage,
                                             builder: IMessageBuilder,
                                             read: IRead,
                                             http: IHttp,
                                             persistence: IPersistence): Promise<IMessage> {
        if (typeof message.text !== 'string') {
            return message;
        }

        const links = message.text.match(this.findRegex);
        const splits = message.text.split(this.findRegex);
        const newLinks: Array<string> = [];

        if (links && links.length > 0) {
            for (const link of links) {
                const parts = this.jiraMatcher().exec(link);

                if (!parts || parts.length < 3) {
                    newLinks.push(link);
                    continue;
                }

                newLinks.push(`[Jira#${parts[2]}](https://jira.bssys.com/browse/${parts[2]})`);
            }
        }
        const newMessageText = newLinks.reduce((wholeText, link, index) => {
            return wholeText + link + splits[index + 1];
        }, splits[0]);

        return builder.setText(newMessageText).getMessage();
    }

    private jiraMatcher = () => /(https?:\/\/)?jira.bssys.com\/browse\/(\w+-\d+)/g;

}
